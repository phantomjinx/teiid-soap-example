
exec StatesView.getAllStateInfo();

exec StatesView.getStateInfo('ny');


