@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.teiid.org/stateService/")
package org.teiid.stateservice;
